export const metadata = {
    title: 'Check Khodam',
}

export default function LandingLayout({ children }) {
    return (
        <div className="">{children}</div>
    )
}
